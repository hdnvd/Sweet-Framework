<?php
namespace core\CoreClasses;
class SweetDate extends \jDateTime {
}

?>