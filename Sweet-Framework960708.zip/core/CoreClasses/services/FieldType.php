<?php
/**
 * Created by PhpStorm.
 * User: Will
 * Date: 9/29/2017
 * Time: 1:52 AM
 */

namespace core\CoreClasses\services;


class FieldType
{
    public static $INTEGER=1;
    public static $EMAIL=2;
    public static $TEXT=3;
    public static $MOBILE=4;
    public static $TEL=5;
    public static $MELLICODE=6;
    public static $URL=7;
}