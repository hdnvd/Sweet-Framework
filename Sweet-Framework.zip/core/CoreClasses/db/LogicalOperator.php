<?php

namespace core\CoreClasses\db;

/**
 *
 * @author nahavandi
 *        
 */
class LogicalOperator {
	CONST LIKE=1;
	CONST Equal=2;
	CONST Between=3;
    CONST Bigger=4;
    CONST Smaller=5;
}

?>