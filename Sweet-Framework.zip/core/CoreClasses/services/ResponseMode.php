<?php

namespace core\CoreClasses\services;

/**
 *
 * @author nahavandi
 *        
 */
class ResponseMode {
	const HTML=0;
	const XML=1;
	const AJAX=2;
	const JSON=3;
	const GZJSON=4;
	
}

?>