<?php
/*
 *@Author:Hadi AmirNahavandi
*@Last Update:2014/5/07
*/
namespace core\CoreClasses\services;
class MessageType{
    public static $INFORMATION=1;
    public static $ERROR=2;
    public static $SUCCESS=3;
    public static $WARNING=4;
}
?>