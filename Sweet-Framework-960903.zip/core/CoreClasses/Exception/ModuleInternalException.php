<?php

namespace core\CoreClasses\Exception;

/**
 *
 * @author nahavandi
 *        
 */
class ModuleInternalException extends SweetException {
	
}

?>