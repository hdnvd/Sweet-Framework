<?php

namespace core\CoreClasses\Rooter;

/**
 *
 * @author nahavandi
 *        
 */
class RooterLink {
	
}

?>