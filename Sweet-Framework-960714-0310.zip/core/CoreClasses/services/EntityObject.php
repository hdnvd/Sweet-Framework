<?php

namespace core\CoreClasses\services;

/**
 *
 * @author Hadi Nahavandi
 *        
 */
class EntityObject  extends ModuleClass{
	
}

?>