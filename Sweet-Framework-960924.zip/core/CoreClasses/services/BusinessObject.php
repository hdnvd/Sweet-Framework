<?php

namespace core\CoreClasses\services;

/**
 *
 * @author hadi
 *        
 */
class BusinessObject extends ModuleClass {
	
}

?>